
var brandId = 456;
// var brandId = 376;
// var brandId = 5771;//正式
// var menuId = '120891';//正式
var menuId = '76658';

module.exports = {
  brandId: brandId,
  clientId: '32e58123cb58fe0bc7ed15933b4537f4fa0d07',
  menuId: menuId
}
